<?php
defined('_JEXEC') or die;
?><?php
/**
 * @package    jodit
 *
 * @author     Valeriy Chupurnov <chupurnov@gmail.com>
 * @copyright  A copyright
 * @license    GNU General Public License version 2 or later; see LICENSE
 * @link       https://xdsoft.net/jodit/
 */


$loader = require __DIR__.'/../vendor/autoload.php';
$loader->addPsr4('', __DIR__);
