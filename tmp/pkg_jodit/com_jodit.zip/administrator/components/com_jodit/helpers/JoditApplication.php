<?php
defined('_JEXEC') or die;
?><?php
/**
 * @package    jodit
 *
 * @author     valera <your@email.com>
 * @copyright  A copyright
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       http://your.url.com
 */

use \Jodit\Application;
class JoditApplication extends Application {
    function checkAuthentication() {}
}