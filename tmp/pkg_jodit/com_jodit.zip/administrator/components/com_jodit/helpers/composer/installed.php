<?php
defined('_JEXEC') or die;
?><?php
/**
 * @package    jodit
 *
 * @author     Valeriy Chupurnov <chupurnov@gmail.com>
 * @copyright  A copyright
 * @license    GNU General Public License version 2 or later; see LICENSE
 * @link       https://xdsoft.net/jodit/
 */
 return array (
  'root' => 
  array (
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'aliases' => 
    array (
    ),
    'reference' => 'c62911696f0e1c9f9586eeed2ee056937be7ae0f',
    'name' => 'jodit/jodit-joomla',
  ),
  'versions' => 
  array (
    'abeautifulsite/simpleimage' => 
    array (
      'pretty_version' => '3.6.5',
      'version' => '3.6.5.0',
      'aliases' => 
      array (
      ),
      'reference' => '00f90662686696b9b7157dbb176183aabe89700f',
    ),
    'dompdf/dompdf' => 
    array (
      'pretty_version' => 'v1.2.0',
      'version' => '1.2.0.0',
      'aliases' => 
      array (
      ),
      'reference' => '60b704331479a69e9bcdb3496da2315b5c4f94fd',
    ),
    'jodit/application' => 
    array (
      'pretty_version' => '3.0.27',
      'version' => '3.0.27.0',
      'aliases' => 
      array (
      ),
      'reference' => '3d1dddde02d29de277bda9d25e6b53593e30e2d0',
    ),
    'jodit/jodit-joomla' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'aliases' => 
      array (
      ),
      'reference' => 'c62911696f0e1c9f9586eeed2ee056937be7ae0f',
    ),
    'league/color-extractor' => 
    array (
      'pretty_version' => '0.3.2',
      'version' => '0.3.2.0',
      'aliases' => 
      array (
      ),
      'reference' => '837086ec60f50c84c611c613963e4ad2e2aec806',
    ),
    'matthecat/colorextractor' => 
    array (
      'replaced' => 
      array (
        0 => '*',
      ),
    ),
    'phenx/php-font-lib' => 
    array (
      'pretty_version' => '0.5.4',
      'version' => '0.5.4.0',
      'aliases' => 
      array (
      ),
      'reference' => 'dd448ad1ce34c63d09baccd05415e361300c35b4',
    ),
    'phenx/php-svg-lib' => 
    array (
      'pretty_version' => '0.4.0',
      'version' => '0.4.0.0',
      'aliases' => 
      array (
      ),
      'reference' => '3ffbbb037f0871c3a819e90cff8b36dd7e656189',
    ),
    'sabberworm/php-css-parser' => 
    array (
      'pretty_version' => '8.4.0',
      'version' => '8.4.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'e41d2140031d533348b2192a83f02d8dd8a71d30',
    ),
  ),
);
